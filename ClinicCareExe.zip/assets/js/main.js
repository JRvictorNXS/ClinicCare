function togglePassword() {
  const input = document.getElementById('password');
  const icon = document.querySelector('.toggle-password');
  if (input.type === 'password') {
    input.type = 'text';
    icon.classList.remove('fa-eye');
    icon.classList.add('fa-eye-slash');
  } else {
    input.type = 'password';
    icon.classList.remove('fa-eye-slash');
    icon.classList.add('fa-eye');
  }
}

const menuBtn = document.getElementById('menuBtn');
const dropdownPanel = document.getElementById('dropdownPanel');

menuBtn.addEventListener('click', () => {
  dropdownPanel.classList.toggle('show');
});

window.addEventListener('click', (e) => {
  if (!menuBtn.contains(e.target) && !dropdownPanel.contains(e.target)) {
    dropdownPanel.classList.remove('show');
  }
});
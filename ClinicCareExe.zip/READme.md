BUrat kaba???????????
backupDaw kasi, di ako pirpik


==========================ClientSide

.navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: #ffffff;
        padding: 0.8em 2em;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        top: 0;
        z-index: 1000;
}

.navbar .logo {
        font-size: 1.4em;
        font-weight: bold;
        color: black;
        text-decoration: none;
}

.nav-right {
        display: flex;
        align-items: center;
        gap: 1.2em;
}

.nav-right i {
        font-size: 1.4em;
        cursor: pointer;
        color: #333;
        transition: color 0.2s;
}

#iconNav {
        padding-right: 0.25em;
        margin-top: 0.51em;
}

.nav-right i:hover {
        color: #8A8CA2;
}

.dropdown-panel {
        display: none;
        position: absolute;
        top: 60px;
        right: 0;
        width: 100%;
        height: auto;
        background: #ffffff;
        box-shadow: -2px 2px 10px rgba(0, 0, 0, 0.2);
        padding: 1em 2em;
        border-radius: 8px 0 0 8px;
        z-index: 10;
}

.dropdown-panel a {
        display: block;
        padding: 0.8em 0;
        color: black;
        text-decoration: none;
        font-weight: 500;
        border-bottom: 1px solid #eee;
        transition: color 0.2s;
}

.dropdown-panel a:hover {
        color: #8A8CA2;
}

.dropdown-panel.show {
        display: block;
}